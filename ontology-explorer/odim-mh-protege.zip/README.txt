Open ODIM-MH.owl in Protege after extracting this archive.
catalog-v001.xml maps imports to the bundled original source documents.
In 'Individuals by class' (Window > Tabs if hidden), expand owl:Thing >
Ontology Layer and select a layer, e.g. Measurement Layer. Its direct
instances, e.g. Measurement, appear in the Individuals pane. Labels or
abbreviated IRIs may be shown depending on your display settings.
The generated layer-membership module represents explicit browser layer
memberships as named individuals; class and property IRIs may be punned.
It does not add inherited memberships or subclass relationships.
Headerless documents use generated copies with package-local ontology
headers; their original source files are also included unchanged.
The unchanged PROV-O source contains two ontology headers; both map to
the same document, imported using the source catalogue's PROV-O alias.

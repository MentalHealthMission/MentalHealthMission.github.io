Open ODIM-MH.owl in Protege after extracting this archive.
catalog-v001.xml maps imports to the bundled original source documents.
Documents without ontology headers use package-local document IRIs.
The unchanged PROV-O source contains two ontology headers; both map to
the same document, imported using the source catalogue's PROV-O alias.
